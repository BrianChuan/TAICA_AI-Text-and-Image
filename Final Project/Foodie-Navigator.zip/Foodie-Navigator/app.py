import gradio as gr
from openai import OpenAI
from huggingface_hub import InferenceClient
import os
import time
import requests
import urllib.parse
import pandas as pd
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from PIL import Image
from dotenv import load_dotenv
load_dotenv()  # 自動尋找並載入 .env 檔案中的變數

# ==========================================
# 0. 環境變數
# ==========================================
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
HF_TOKEN = os.getenv("HF_TOKEN")

# 全域變數
global_df = None
global_mood_df = None
global_retriever = None
rag_initialized = False

# ==========================================
# 1. 系統初始化 (讀取 CSV + 讀取 FAISS)
# ==========================================
def init_rag_system():
    global global_df, global_mood_df, global_retriever, rag_initialized
    
    if rag_initialized: return

    print("⏳ 正在初始化系統...")
    
    # --- A. 讀取 CSV (用於篩選與對照) ---
    try:
        global_df = pd.read_csv('restaurants.csv')
        global_df['RAG_Content'] = global_df['RAG_Content'].fillna("")
        global_df['Category'] = global_df['Category'].fillna("其他")
        
        global_mood_df = pd.read_csv('mood_food_guide.csv')
        print(f"✅ CSV 資料讀取成功 (餐廳: {len(global_df)} 筆)")
    except Exception as e:
        print(f"❌ CSV 讀取失敗: {e}")
        return

    # --- B. 讀取預先建立好的 FAISS 索引 ---
    # 這裡不再重新建立，而是直接讀取 "faiss_index" 資料夾
    if os.path.exists("faiss_index"):
        try:
            print("⏳ 正在載入 FAISS 向量資料庫...")
            embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
            
            # allow_dangerous_deserialization=True 是必要的，因為我們讀取 pickle 檔
            # 由於這是我們自己建立的檔案，所以是安全的
            vectorstore = FAISS.load_local(
                "faiss_index", 
                embeddings, 
                allow_dangerous_deserialization=True
            )
            global_retriever = vectorstore.as_retriever(search_kwargs={"k": 3})
            print("✅ FAISS 資料庫載入完成！")
        except Exception as e:
            print(f"❌ FAISS 載入失敗: {e}")
    else:
        print("⚠️ 警告：找不到 'faiss_index' 資料夾，RAG 功能將無法使用。")
        print("請先執行 build_index.py 並上傳資料夾。")

    rag_initialized = True

# ==========================================
# 2. 小測驗與資源設定
# ==========================================
custom_css = """
#hidden_tabs > .tab-nav { display: none !important; visibility: hidden !important; }
#hidden_tabs > div > button { display: none !important; }
.vertical-radio fieldset { display: flex !important; flex-direction: column !important; gap: 12px !important; }
.vertical-radio label { width: 100% !important; margin: 0 !important; display: flex !important; }
"""

img_path_1 = "images/image_0.png"
img_path_2 = "images/image_1.png"

if not os.path.exists("images"): os.makedirs("images")
if not os.path.exists(img_path_1): Image.new('RGB', (400, 300), color='gray').save(img_path_1)
if not os.path.exists(img_path_2): Image.new('RGB', (400, 300), color='lightblue').save(img_path_2)

q1_options_map = {
    "不​要​再​問白癡​問題​了​我​只​想​吃飯​": "現實主義者 (只想吃飯)",
    "去​過隱​居​生活": "隱士 (嚮往平靜)",
    "加入​禁衛軍，​保衛​這個​世界": "守護者 (充滿正義感)",
    "神​羅​天​征，毀滅這個​世界​": "破壞神 (心情可能很差或很中二)"
}

q2_options_map = {
    "不​要​再​問白癡​問題​了​我​只​想​吃飯​": "無魔法 (飢餓度MAX)",
    "麵​包形狀​的​魔法​炸彈": "爆炸魔法 (喜歡刺激/重口味)",
    "毒氣​的​生化​魔法": "毒氣魔法 (可能想吃臭豆腐或特殊風味)",
    "領域​展開:​無量​空處​": "領域展開 (思緒混亂或想放空)"
}

# ==========================================
# 3. 核心功能
# ==========================================

def get_restaurant_data(mood_score_str, food_choice):
    init_rag_system()
    if global_df is None or global_df.empty: return None, True, "資料庫未載入", "無建議"
    
    try:
        score = int(str(mood_score_str).split(' ')[0])
    except:
        score = 3
    
    mood_info = global_mood_df[global_mood_df['分數'] == score]
    if not mood_info.empty:
        rec_categories = mood_info.iloc[0]['推薦料理類別']
        mood_reason = mood_info.iloc[0]['原因']
    else:
        rec_categories = ""
        mood_reason = "隨意探索"

    candidates = global_df.copy()
    
    if rec_categories:
        candidates = candidates[candidates['Category'].apply(lambda x: str(x) in str(rec_categories) or str(rec_categories) in str(x))]
        
    food_keyword = "飯" if food_choice == "吃飯" else "麵" if food_choice == "吃麵" else ""
    if food_keyword:
        candidates = candidates[
            candidates['Name'].str.contains(food_keyword, case=False, na=False) | 
            candidates['RAG_Content'].str.contains(food_keyword, case=False, na=False)
        ]
    
    if candidates.empty:
        result = global_df.sample(1).iloc[0]
        is_random = True
    else:
        result = candidates.sample(1).iloc[0]
        is_random = False
        
    return result, is_random, rec_categories, mood_reason

def generate_content_with_groq(restaurant_name, restaurant_detail, user_diary, mood_score, quiz_result, mood_guide_reason):
    if not GROQ_API_KEY: return "⚠️ 請設定 GROQ_API_KEY"
    
    client = OpenAI(api_key=GROQ_API_KEY, base_url="https://api.groq.com/openai/v1")
    
    system_prompt = "你是一個幽默、懂吃且善解人意的 AI 朋友。請根據使用者的日記、心情以及「心情美食指南」來推薦餐廳。"
    user_msg = f"""
    【狀態】心情分數：{mood_score}，日記：{user_diary}
    【測驗結果】人設：{quiz_result.get('q1', '未知')}，魔法：{quiz_result.get('q2', '未知')}
    
    【心情美食指南建議】
    因為分數是 {mood_score}，建議吃這類食物的原因是：「{mood_guide_reason}」。
    
    【推薦餐廳】
    名稱：{restaurant_name}
    資料：{restaurant_detail}
    
    任務：
    請用繁體中文寫一段溫暖有趣的回覆：
    1. 先回應他的日記與測驗人設。
    2. 引用「心情美食指南」的原因，告訴他為什麼現在適合吃這家餐廳（例如：「就像指南說的，現在你需要一點多巴胺...」）。
    3. 介紹這家餐廳的特色。
    (只需要回覆文字內容)
    """
    try:
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile", messages=[{"role": "system", "content": system_prompt}, {"role": "user", "content": user_msg}]
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"Groq Error: {str(e)}"

def generate_image_huggingface(prompt):
    if not HF_TOKEN: return None
    if not prompt or pd.isna(prompt): prompt = "Delicious gourmet food, photorealistic, 8k"
        
    try:
        hf_client = InferenceClient(token=HF_TOKEN)
        return hf_client.text_to_image(prompt=prompt, model="stabilityai/stable-diffusion-xl-base-1.0")
    except Exception as e:
        print(f"❌ 生圖失敗: {e}")
        return None

def mood_agent_logic(score_input, food_input, diary_input, quiz_state):
    restaurant, is_random, rec_categories, mood_reason = get_restaurant_data(score_input, food_input)
    
    if restaurant is None:
        yield "資料庫讀取錯誤", None, ""
        return

    name = restaurant['Name']
    address = restaurant['Address']
    url = restaurant['URL']
    img_prompt = restaurant.get('Visual_prompt') 
    note = "(隨機推薦)" if is_random else ""

    # RAG 檢索 (直接用 global_retriever)
    rag_info = str(restaurant.get('RAG_Content', ''))
    if global_retriever:
        docs = global_retriever.invoke(name)
        if docs:
            rag_info = "\n".join([d.page_content for d in docs])

    ai_text = generate_content_with_groq(name, rag_info, diary_input, score_input, quiz_state, mood_reason)
    
    final_response = f"### 🍽️ 推薦：{name} {note}\n\n{ai_text}"
    map_html = f'<div style="text-align:center"><a href="{url}" target="_blank" style="background:#4CAF50;color:white;padding:8px 16px;border-radius:20px;text-decoration:none">🗺️ Google Map 導航</a></div>'
    
    yield final_response, None, map_html
    image_output = generate_image_huggingface(img_prompt)
    yield final_response, image_output, map_html

# ==========================================
# 4. 介面互動邏輯
# ==========================================
# (這部分與之前相同，略)
def handle_q1_change(selected_label, current_state):
    if not selected_label: return current_state, gr.Button(interactive=False)
    current_state["q1"] = q1_options_map[selected_label]
    return current_state, gr.Button(interactive=True, variant="primary")

def handle_q2_change(selected_label, current_state):
    if not selected_label: return current_state, gr.Button(interactive=False)
    current_state["q2"] = q2_options_map[selected_label]
    return current_state, gr.Button(interactive=True, variant="primary", value="完成測驗 (前往點餐) ➔")

# ==========================================
# 5. Gradio 介面建構
# ==========================================
with gr.Blocks(title="AI 心情食堂") as demo:
    gr.HTML(f"<style>{custom_css}</style>")
    quiz_state = gr.State(value={})

    with gr.Tabs(elem_id="hidden_tabs") as tabs:
        # Tab 0: Q1
        with gr.TabItem("Q1", id=0):
            with gr.Column():
                gr.Markdown("### 🔮 第一題：直覺測試")
                gr.Image(value=img_path_1, type="filepath", label="請觀察圖片", height=300)
                gr.Markdown("**問題：請觀察上方圖片，如果是你，你會怎麼做？**")
                radio_q1 = gr.Radio(choices=list(q1_options_map.keys()), label="請選擇", elem_classes="vertical-radio")
                btn_q1_next = gr.Button("下一頁 ➔", interactive=False)

        # Tab 1: Q2
        with gr.TabItem("Q2", id=1):
            with gr.Column():
                gr.Markdown("### 🔮 第二題：魔法適性")
                gr.Image(value=img_path_2, type="filepath", label="請觀察圖片", height=300)
                gr.Markdown("**問題：身為魔導士的你，會選擇哪一個法術？**")
                radio_q2 = gr.Radio(choices=list(q2_options_map.keys()), label="請選擇", elem_classes="vertical-radio")
                btn_q2_finish = gr.Button("完成測驗 ➔", interactive=False)

        # Tab 2: Main
        with gr.TabItem("Main", id=2):
            with gr.Column():
                gr.Markdown(f"## 🍱 呷飽沒？？！")
                with gr.Row():
                    with gr.Column(scale=1):
                        score_input = gr.Radio(["1 (心情差)", "2 (不太好)", "3 (普通)", "4 (不錯)", "5 (超棒)"], label="1. 心情分數", value="3 (普通)")
                        food_input = gr.Radio(["吃飯", "吃麵", "隨便"], label="2. 想吃什麼", value="隨便")
                        diary_input = gr.Textbox(lines=4, label="3. 心情日記", placeholder="寫下今天發生的事...")
                        submit_btn = gr.Button("送出給 Agent", variant="primary")
                    with gr.Column(scale=1):
                        agent_output = gr.Markdown(label="AI 回應")
                        image_output = gr.Image(label="AI 推薦美食圖", type="pil", width=400)
                        map_output = gr.HTML(label="地圖導航")

    radio_q1.change(fn=handle_q1_change, inputs=[radio_q1, quiz_state], outputs=[quiz_state, btn_q1_next])
    btn_q1_next.click(fn=lambda: gr.Tabs(selected=1), outputs=tabs)
    radio_q2.change(fn=handle_q2_change, inputs=[radio_q2, quiz_state], outputs=[quiz_state, btn_q2_finish])
    btn_q2_finish.click(fn=lambda: gr.Tabs(selected=2), outputs=tabs)

    submit_btn.click(
        fn=mood_agent_logic,
        inputs=[score_input, food_input, diary_input, quiz_state],
        outputs=[agent_output, image_output, map_output]
    )

if __name__ == "__main__":
    demo.launch(ssr_mode=False)