import pandas as pd
import os
from langchain_community.document_loaders import DataFrameLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS

def build_vector_db():
    print("⏳ 開始建立向量資料庫 (Build 模式)...")
    
    # 1. 讀取資料
    try:
        df = pd.read_csv('restaurants.csv')
        df['RAG_Content'] = df['RAG_Content'].fillna("")
        print(f"✅ 讀取餐廳資料：{len(df)} 筆")
    except Exception as e:
        print(f"❌ 錯誤：找不到 restaurants.csv ({e})")
        return

    # 2. 準備向量化
    loader = DataFrameLoader(df, page_content_column="RAG_Content")
    documents = loader.load()
    
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    docs = text_splitter.split_documents(documents)
    
    # 3. 下載模型並建立索引
    print("⏳ 下載 Embedding 模型中...")
    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    
    print("⏳ 建立 FAISS 索引中...")
    vectorstore = FAISS.from_documents(docs, embeddings)
    
    # 4. 儲存到本地資料夾
    save_path = "faiss_index"
    vectorstore.save_local(save_path)
    print(f"✅ 向量資料庫已儲存至 '{save_path}' 資料夾！")

if __name__ == "__main__":
    build_vector_db()